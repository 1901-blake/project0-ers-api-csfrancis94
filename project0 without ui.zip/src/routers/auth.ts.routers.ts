import express from 'express';
import { resolvePtr } from 'dns';
import { User } from '../models/user';
import { Role } from '../models/role';

export const authRouter = express.Router();

//create some dummy users
let u1 : User = new User(0,"bob", "pass", "robert", "pass", "bobrob@gmail.com", new Role(0, "normal"));
let u2 : User = new User(0,"sam", "pass", "robert", "pass", "bobrob@gmail.com", new Role(0, "normal"));
let u3 : User = new User(0,"meg", "pass", "robert", "pass", "bobrob@gmail.com", new Role(0, "normal"));

let users : User[] = [u1, u2, u3];



/*
authRouter.post('/login', (req, res) => {
  if (req.body.username === 'blake' && req.body.password === 'password') {
    const user = {
      username: req.body.username,
      role: 'admin'
    }
    req.session.user = user
    res.json(user);
  } else if (req.body.username === 'hank' && req.body.password === 'password') {
    const user = {
      username: req.body.username,
      role: 'associate'
    }
    req.session.user = user;
    res.json(user);
  } else {
    res.sendStatus(401);
  }
})


authRouter.get('/info', (req, res) => {
  res.json(req.session.user);
})
*/


//allows logins, but only thru post. returns the user found thru post request
authRouter.post('/', (req, res) => {

  let match = -1;
  console.log("Credentials supplied: " + req.body["username"] + ":" + req.body["password"]);
  //"application/json; charset=UTF-8"
  for (let i = 0; i < users.length; i++)
          if (users[i].username == req.body["username"])
                  if (users[i].password == req.body["password"])
                          match = i;

  if (match >= 0)
          //set session variable here

          //send the JSON users object
          res.send(JSON.stringify(users[match]));
  else    
  {
          res.status(400);
          res.json("Invalid Credentials");
  }
  
});
