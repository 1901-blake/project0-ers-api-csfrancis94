export class ReimbursementType{
        typeId: number; // primary key
        type: string; // not null, unique


constructor(typeId : number, type: string)
{
        
        this.typeId = typeId, // primary key
        this.type = type // not null, unique
        
}

}