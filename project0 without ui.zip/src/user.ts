export class User{
id:number;
username:string;
password:string;
name:string;


constructor(id = 0, username = '',  password = '', name = '')
{
        this.name = name;
        this.username = username;
        this.password = password; 
        this.id = id;

    
}

}