export class Artist {
artistid: number;
name: string;
}