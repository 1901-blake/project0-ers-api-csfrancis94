import {ArtistDao} from "./artist-data";

console.log("Hello world");

let artistDao = new ArtistDao()
artistDao.getAllArtist().then(artArray => console.log(artArray));